A reflex wrapping react component: react-responsive-carousel
